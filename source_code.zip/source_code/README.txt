To Access Web Page: 
unaginagi.pythonanywhere.com 


To Run Program on LocalHost:

Prerequisites:
	Python 3.x and above installed
	in terminal:
		run 'pip install -r requirements.txt' to install the necessary packages
		run 'set PYTHONHASHSEED=0'  for default admin to work


	XAMPP is installed
	MySQL is installed
	Run Apache and MyQL in XAMPP
	Click `admin` button on MySQL
	Create a database called `registered` in phpMyAdmin page
	Run `registered.sql` file
	make sure all files in source code folder is in "C:/xampp/htdocs/login/"

Steps:
	In Terminal:
		run 'python3 C:/xampp/htdocs/login/connector.py'

	Open browser
	enter localhost:5000 into the address bar